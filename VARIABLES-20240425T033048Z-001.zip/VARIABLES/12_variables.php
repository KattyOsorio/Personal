<?php
echo "Por favor, introduce la longitud del primer cateto: ";
$cateto1=readline();
echo "Por favor, introduce la longitud del segundo cateto: ";
$cateto2=readline();
$Hipotenusa=$cateto1*$cateto1+$cateto2*$cateto2;
echo"la longitud de la hipotenusa es: $Hipotenusa  ";
?>
 