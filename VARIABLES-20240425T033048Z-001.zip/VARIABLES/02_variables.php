<?php 
echo "por favor introduce un numero";
$numero= readline();
$cuadrado=$numero*$numero;
echo"El cuadrado del numero $numero es: $cuadrado";
?>