<?php
echo "por favor introdusca la velocidad en kilometros por hora";
$velocidad=readline();
echo"tiempo en horas ";
$horas=readline();
$distancia=$velocidad*$horas;
echo "la distacia recorridad es : $distancia Kilometros"
?>