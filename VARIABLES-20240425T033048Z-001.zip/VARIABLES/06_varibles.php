<?php
echo "por favor introduce el numero:  ";
$numero=readline();
$porcentaje_30=$numero*0.30;
$porcentaje_60=$numero*0.60;
$porcentaje_90=$numero*0.90;
echo"el porcentaje del primer numero es: $porcentaje_30";
echo "el porcentaje del segunod numero es: $porcentaje_60";
echo "el porcentaje del tercer numero es: $porcentaje_90";
?>