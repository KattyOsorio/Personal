<?php
$numero1 = readline("Introduce el primer número: ");
$numero2 = readline("Introduce el segundo número: ");
$numero3 = readline("Introduce el tercer número: ");
$resultado = $numero1 * $numero2 * $numero3;
echo "El resultado de la multiplicación es: " . $resultado;
echo "El resultado de la multiplicación es: {$resultado}";
?>