<?php
echo "por favor introduce el numero del primer lado:";
$lado1=readline();
echo "por favor introduzca el segundo lado: ";
$lado2=readline();  
$AREA=$lado1*$lado2;
echo"el area del cuadrado es: $area ";
?>