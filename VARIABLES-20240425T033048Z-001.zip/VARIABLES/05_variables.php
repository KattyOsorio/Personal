<?php
echo "por favor introduce el numero:  ";
$numero=readline();
$porcentaje=$numero*0.20;
echo"el porcentaje del numero es: $porcentaje";
?>